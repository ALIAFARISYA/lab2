// ===== 4. AUTOMATIC SLIDESHOW WITH CONTROLS =====
let slideIndex = 0;
let slideInterval;

function startSlideshow() {
    slideInterval = setInterval(() => {
        moveSlide(1);
    }, 4000);
}

function moveSlide(n) {
    showSlide(slideIndex += n);
}

function showSlide(n) {
    const slides = document.getElementsByClassName("slide");
    
    if (n >= slides.length) { slideIndex = 0; }
    if (n < 0) { slideIndex = slides.length - 1; }
    
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    
    slides[slideIndex].style.display = "block";
}

// Initialize slideshow
document.addEventListener('DOMContentLoaded', function() {
    showSlide(slideIndex);
    startSlideshow();
    
    // Add manual controls
    document.getElementById('prev-btn').addEventListener('click', () => {
        clearInterval(slideInterval);
        moveSlide(-1);
        startSlideshow();
    });
    
    document.getElementById('next-btn').addEventListener('click', () => {
        clearInterval(slideInterval);
        moveSlide(1);
        startSlideshow();
    });
    
    // Pause on hover
    const slideshow = document.querySelector('.slideshow-container');
    slideshow.addEventListener('mouseenter', () => clearInterval(slideInterval));
    slideshow.addEventListener('mouseleave', startSlideshow);
});

// ===== 6. PROGRESS BAR WITH COUNTRIES =====
const progressBar = document.getElementById("progress-bar");
const currentCount = document.getElementById("current-count");
const countriesList = document.getElementById("countries-visited");
const addCountryBtn = document.getElementById("add-country");
const resetProgressBtn = document.getElementById("reset-progress");

const sampleCountries = [
    "Japan", "Italy", "Australia", "Thailand", "France", 
    "Canada", "Spain", "Greece", "Vietnam", "Brazil", 
    "Portugal", "New Zealand", "Iceland", "Morocco", "South Africa"
];

let visitedCountries = [];
let progress = 0;

function updateProgress() {
    progress = (visitedCountries.length / 12) * 100;
    progressBar.style.width = `${progress}%`;
    currentCount.textContent = visitedCountries.length;
    
    // Update countries list
    countriesList.innerHTML = "";
    visitedCountries.forEach(country => {
        const li = document.createElement("li");
        li.innerHTML = `<i class="fas fa-map-marker-alt"></i> ${country}`;
        countriesList.appendChild(li);
    });
}

addCountryBtn.addEventListener("click", function() {
    if (visitedCountries.length < 12) {
        // Get a random country from sample list
        const availableCountries = sampleCountries.filter(c => !visitedCountries.includes(c));
        if (availableCountries.length > 0) {
            const randomCountry = availableCountries[Math.floor(Math.random() * availableCountries.length)];
            visitedCountries.push(randomCountry);
            updateProgress();
            
            // Show celebration when goal is reached
            if (visitedCountries.length === 12) {
                setTimeout(() => {
                    alert("🎉 Congratulations! You've reached your travel goal for 2025!");
                }, 500);
            }
        } else {
            alert("All sample countries have been added! Try resetting to start over.");
        }
    } else {
        alert("You've already visited 12 countries! Goal completed! 🎉");
    }
});

resetProgressBtn.addEventListener("click", function() {
    if (confirm("Reset your travel progress? This will clear all visited countries.")) {
        visitedCountries = [];
        updateProgress();
    }
});

// ===== 7. COLLAPSIBLE FAQ =====
const collapsibles = document.getElementsByClassName("collapsible");

for (let i = 0; i < collapsibles.length; i++) {
    collapsibles[i].addEventListener("click", function() {
        this.classList.toggle("active");
        const content = this.nextElementSibling;
        
        // Close all other open items
        for (let j = 0; j < collapsibles.length; j++) {
            if (collapsibles[j] !== this) {
                collapsibles[j].classList.remove("active");
                collapsibles[j].nextElementSibling.style.maxHeight = null;
            }
        }
        
        // Toggle current item
        if (content.style.maxHeight) {
            content.style.maxHeight = null;
        } else {
            content.style.maxHeight = content.scrollHeight + "px";
        }
    });
}

// Open first FAQ by default
if (collapsibles.length > 0) {
    collapsibles[0].classList.add("active");
    collapsibles[0].nextElementSibling.style.maxHeight = 
        collapsibles[0].nextElementSibling.scrollHeight + "px";
}

// ===== NEWSLETTER FORM =====
document.getElementById("newsletter-form").addEventListener("submit", function(e) {
    e.preventDefault();
    
    const name = this.querySelector('input[type="text"]').value;
    const email = this.querySelector('input[type="email"]').value;
    
    // Simple validation
    if (name && email) {
        alert(`Thank you, ${name}! You've successfully subscribed to our travel newsletter. Welcome to the Adventure Wanderlust community! ✈️`);
        this.reset();
    } else {
        alert("Please fill in all required fields.");
    }
});

// ===== CONTACT BUTTON =====
document.querySelector(".contact-btn").addEventListener("click", function() {
    const modal = document.createElement("div");
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.7);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 2000;
    `;
    
    modal.innerHTML = `
        <div style="background: white; padding: 30px; border-radius: 15px; max-width: 500px; width: 90%;">
            <h3 style="color: #2c3e50; margin-bottom: 20px;">Contact Alia</h3>
            <p>For collaborations, sponsored trips, or speaking engagements, please email:</p>
            <p style="background: #f8f9fa; padding: 15px; border-radius: 8px; font-weight: bold; color: #FF7E5F;">
                alia@adventurewanderlust.com
            </p>
            <button id="close-modal" style="background: #FF7E5F; color: white; border: none; padding: 10px 25px; border-radius: 5px; margin-top: 20px; cursor: pointer;">
                Close
            </button>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    document.getElementById("close-modal").addEventListener("click", function() {
        document.body.removeChild(modal);
    });
    
    modal.addEventListener("click", function(e) {
        if (e.target === modal) {
            document.body.removeChild(modal);
        }
    });
});

// ===== SIDE NAV SCROLL =====
document.querySelectorAll('.side-nav a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const targetId = this.getAttribute('href');
        
        if(targetId.startsWith('#')) {
            const targetElement = document.querySelector(targetId);
            if(targetElement) {
                // Close mobile nav if open
                if (window.innerWidth <= 1200) {
                    document.querySelector('.side-nav').style.height = 'auto';
                }
                
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        }
    });
});

// ===== ADD SOME INTERACTIVE COLOR CHANGES =====
document.querySelectorAll('.social-btn, .cta-button, #add-country').forEach(button => {
    button.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-5px)';
    });
    
    button.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0)';
    });
});
    